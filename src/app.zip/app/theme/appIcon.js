export const ICON = {
    Home: require('../../assets/icons/ic_home.png'),
    Save: require('../assets/icons/ic_save.png'),
    Cart: require('../assets/icons/ic_cart.png'),
    Profile: require('../../assets/icons/ic_user.png'),

    HomeFocus: require('../../assets/icons/ic_home_focus.png'),
    SaveFocus: require('../assets/icons/ic_save_focus.png'),
    CartFocus: require('../assets/icons/ic_cart_focus.png'),
    ProfileFocus: require('../../assets/icons/ic_user_focus.png'),




}
