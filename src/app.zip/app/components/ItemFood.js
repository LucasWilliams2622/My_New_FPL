import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ItemFood = () => {
  return (
    <View>
      <Text>ItemFood</Text>
    </View>
  )
}

export default ItemFood

const styles = StyleSheet.create({})